#!/usr/bin/env python3

'''
Copyright 2022 NXP.

This software is owned or controlled by NXP and may only be used strictly in accordance with the
license terms that accompany it. By expressly accepting such terms or by downloading, installing,
activating and/or otherwise using the software, you are agreeing that you have read, and that you
agree to comply with and are bound by, such license terms. If you do not agree to be bound by the
applicable license terms, then you may not retain, install, activate or otherwise use the software.

'''

import base64
import subprocess
import sys
import os
import math
import argparse
from enum import IntEnum
import mmap
import string

from sign_pass import get_signing_passphrase

import Ivaldi.elftosb as elftosb
import Ivaldi.helpers as hlpr

OUT_DIR_NAME = './'
SIGN_ENTITY_KEY_DIR = '../ca/private/'
SIGN_ENTITY_CRT_DIR = '../ca/certs/'
BUNDLE_CERT = ''

DISABLE_IMAGE_VERIFICATION = False

def sign(sign_entity, pkey_pass, in_file):
    """
    Signs the given in_file with sign_entity certificate.
    """

    # Sign the file and output the signature raw and base64
    print("Signing %s ..." % in_file)
    sign_key = SIGN_ENTITY_KEY_DIR + sign_entity + '.key.pem'
    base_name = os.path.basename(in_file)
    sig_raw_file = OUT_DIR_NAME + '/' + base_name + '.sha256'
    sign_crt = SIGN_ENTITY_CRT_DIR + sign_entity + '.crt.pem'

    cmd3 = ['openssl', 'dgst', '-sha256', '-sign', sign_key, '-passin', 'pass:' + pkey_pass, '-out', sig_raw_file, in_file]
    out = subprocess.run(cmd3, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if out.returncode == 0:
        print("SUCCESS: Signature created.")
    else:
        print("ERROR: Could not sign." + "  " + pkey_pass + "  " + str(out.stderr, 'utf-8', 'strict'))
        sys.exit(1)

    # Extract public key from certificate
    cmd4 = ['openssl', 'x509', '-in', sign_crt, '-pubkey', '-noout']
    out = subprocess.run(cmd4, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if out.returncode == 0:
        with open('./foo.pem', 'w+') as pk:
            pk.write(str(out.stdout, 'utf-8', 'strict'))
            pk.close()
    else:
        print("ERROR: Could not extract public key.")
        print(str(out.stdout.strip(), 'utf-8', 'strict'))
        print(str(out.stderr.strip(), 'utf-8', 'strict'))
        sys.exit(1)

def verify_signature(in_file):
    """
    Verifies the signature after the signing is performed.
    """

    # Verify signature
    base_name = os.path.basename(in_file)
    sig_raw_file = OUT_DIR_NAME + '/' + base_name + '.sha256'
    cmd5 = ['openssl', 'dgst', '-sha256', '-verify', './foo.pem', '-signature', sig_raw_file, in_file]
    out = subprocess.run(cmd5, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if out.returncode == 0:
        print("SUCCESS: Signature verified.")
        os.remove('./foo.pem')
    else:
        print("ERROR: Could not verify.")
        print(str(out.stdout.strip(), 'utf-8', 'strict'))
        print(str(out.stderr.strip(), 'utf-8', 'strict'))
        os.remove('./foo.pem')
        sys.exit(1)

def int_to_bytes(data, sz, dataList):
    shift_count = 0
    while (shift_count < sz):
        dataList.append(((data >> shift_count) & 0xFF))
        shift_count += 8

def write_file(in_file, writeFlags, trunc=False):
    """
    Writes the given file in the bundle.
    """
    global FINAL_BUNDLE

    print("Writing file " + in_file + " ...")

    # Open up the bundle file
    bunFile = open(FINAL_BUNDLE, writeFlags)

    if trunc:
        bunFile.truncate(0)

    # Copy original contents to file
    in_txt = bytearray()
    with open(in_file, 'rb') as inF:
        in_txt = inF.read()
        inF.close()

    bunFile.write(in_txt)
    bunFile.close()

def write_bundle_metadata(in_file, modules_nr, bundle_cert):
    """
    Writes the bundle metadata.

    Updater bundle metadata sections:
    |--upd-start-addr--|--upd-code-size--|--upd-bundle-size--|--upd-modules-nr--|
    """

    bunFile = open(FINAL_BUNDLE, 'a+b')
    dataList = []

    #Add bundle size
    bundle_size = os.path.getsize(in_file)
    int_to_bytes(bundle_size, 32, dataList)
    #Add number of modules
    int_to_bytes(modules_nr, 32, dataList)

    bunFile.write(bytearray(dataList))


    if DISABLE_IMAGE_VERIFICATION == True:
        PKEY_PASS = get_signing_passphrase(bundle_cert)

        sign_crt = sign(bundle_cert, PKEY_PASS, in_file)
        verify_signature(in_file)

        base_name = os.path.basename(in_file)
        sig_raw_file = OUT_DIR_NAME + '/' + base_name + '.sha256'

        with open(sig_raw_file, 'rb') as rSig:
            raw_sig = rSig.read()
            rSig.close()
        os.remove(sig_raw_file)

    bunFile.write(raw_sig)
    bunFile.close()

    bunFile.close()

def write_module_metadata(cert_filename, module_type, module_starting_addr, in_file=None):
    """
    Writes the metadata for an updater module.

    Module metadata, signed binary case:
    |--binary-type--|--binary-start-addr--|--binary-size--|--binary-signature--|

    """
    bunFile = open(FINAL_BUNDLE, 'a+b')
    dataList = []

    #Add module type
    int_to_bytes(module_type, 32, dataList)

    #Add module starting addr
    int_to_bytes(module_starting_addr, 32, dataList)
    #Add binary size
    binary_size = os.path.getsize(in_file)

    int_to_bytes(binary_size, 32, dataList)
    bunFile.write(bytearray(dataList))

    raw_sig = bytearray(256)
    if DISABLE_IMAGE_VERIFICATION == True:

        PKEY_PASS = get_signing_passphrase(cert_filename)

        sign_crt = sign(cert_filename, PKEY_PASS, in_file)
        verify_signature(in_file)

        base_name = os.path.basename(in_file)
        sig_raw_file = OUT_DIR_NAME + '/' + base_name + '.sha256'

        with open(sig_raw_file, 'rb') as rSig:
            raw_sig = rSig.read()
            rSig.close()
        os.remove(sig_raw_file)

    bunFile.write(raw_sig)
    bunFile.close()

def get_arguments():
    """
    Arguments parsing function.
    Restrictions checking.
    Global variables setting.
    """

    global OUT_DIR_NAME
    global DISABLE_IMAGE_VERIFICATION
    # Parameters description
    ########################
    parser = argparse.ArgumentParser()

    parser.add_argument('-bf', '--bundle-folder', required=True, type=str, help="Specify the folder that contains bundle_config.py file")
    parser.add_argument('-cf', '--config-folder', required=True , type=str, help="Specify the folder that contains board_config.py file")
    parser.add_argument('-d', '--bundle-path', default="./output", type=str, help="Output path of the bundle img. Default is working directory")
    parser.add_argument('-ivd', '--image-verification-disable', action='store_false', help="Disable Image Verification")

    args = parser.parse_args()

    if (args.image_verification_disable):
        DISABLE_IMAGE_VERIFICATION = True

    OUT_DIR_NAME = args.bundle_path
    return args

def get_image_list(bundle_config_path, board_config_path):
    """ Import bundle list that contains the files that need to be loaded """

    global FINAL_BUNDLE
    global BUNDLE_NAME
    global BUNDLE_CERT
    global BANK_SIZE
    global SIGN_ENTITY_KEY_DIR
    global SIGN_ENTITY_CRT_DIR

    try:
        sys.path.append(bundle_config_path)
        print('Importing files_list.py from ' + bundle_config_path + ' folder')
        import bundle_config
    except ImportError:
        print('ERROR: Could not import bundle_config.py file from ' + bundle_config_path + ' folder')
        sys.exit(1)

    try:
        sys.path.append(board_config_path)
        import board_config
    except ImportError:
        print('ERROR: Could not import board_config.py file from ' + board_config_path + ' folder')
        sys.exit(1)

    # Restrictions verification
    ###########################

    unique_list = []
    for image in bundle_config.imageBundleList:
        if image.module_type not in unique_list:
            unique_list.append(image.module_type)
        else:
            print('Double entries for image binary ' + image.module_type)
            sys.exit(1)


    # Global variables assignement
    ##############################

    BANK_SIZE   = int(board_config.BANK_SIZE, 16)
    BUNDLE_NAME = bundle_config.BUNDLE_NAME
    BUNDLE_CERT  = bundle_config.BUNDLE_CERT
    FINAL_BUNDLE = OUT_DIR_NAME + '/' + BUNDLE_NAME

    return bundle_config.imageBundleList

def main():

    # Parsing the arguments
    #######################
    args = get_arguments()
    image_bundle_list = get_image_list(args.bundle_folder, args.config_folder)


    # Determine updater modules number
    ##################################
    modules_nr = len(image_bundle_list)

    print("\r\nStarting to create an updater bundle with " + str(modules_nr) + " {} ...\r\n".format("module" if modules_nr == 1 else "modules"))

    if os.path.exists(FINAL_BUNDLE):
        os.remove(FINAL_BUNDLE)
    open(FINAL_BUNDLE, 'a').close()

    for img in image_bundle_list:
        module_type = img.module_type
        path_bin = img.path_bin
        path_cert = img.path_cert

    # Add images
    ############
        print('\r\nStart writing mod' + str(module_type) + ' from the address ' + path_bin + ' signed with cert ' + path_cert + '\r\n')
        module_starting_addr = os.path.getsize(FINAL_BUNDLE)
        write_file(path_bin, 'a+b')
    # Add module metadata and the module itself, for all possible modules
    #####################################################################
        write_module_metadata(path_cert, module_type, module_starting_addr, path_bin)

    #Add bundle metadata
    write_bundle_metadata(FINAL_BUNDLE, modules_nr, BUNDLE_CERT)

    bundle_final_size = os.path.getsize(FINAL_BUNDLE)
    if bundle_final_size < BANK_SIZE:
        print('SUCCESS: Bundle size: ' + str(os.path.getsize(FINAL_BUNDLE)) + ' bytes')
    else:
        print('Error: Bundle size ' + str(bundle_final_size) + ' bytes is bigger than available Bank Size ' + str(BANK_SIZE) + ' bytes')
        sys.exit(1)

    cmd3 = ['python', 'sign_me.py', FINAL_BUNDLE, BUNDLE_CERT]
    out = subprocess.run(cmd3, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if out.returncode != 0:
        print('ERROR: sign_me.py failed')
        print(str(out.stdout.strip(), 'utf-8', 'strict'))
        print(str(out.stderr.strip(), 'utf-8', 'strict'))
        sys.exit(1)

if __name__== "__main__":
  main()