# Littlefs prebuild

This littlefs generator uses littlefs-python 0.3.0 wrapper.
The current version of the wrapper does not support attributes for littlefs which stops us to
implement encryption files.

