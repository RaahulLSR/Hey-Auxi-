# Platform Configurations

Each folder contains specifications for a different platform.