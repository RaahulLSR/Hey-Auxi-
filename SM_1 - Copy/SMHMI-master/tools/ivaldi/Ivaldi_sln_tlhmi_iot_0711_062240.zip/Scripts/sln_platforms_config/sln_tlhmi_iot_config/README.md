# SLN-TLHMI-IOT Board Config

board_config.py defines the board config of the SLN-TLHMI-IOT

littlefs_file_list.py defines the files required to be stored in the File System of the device for different configurations:
 - with/without AWS
 - with/without Image Verification feature
