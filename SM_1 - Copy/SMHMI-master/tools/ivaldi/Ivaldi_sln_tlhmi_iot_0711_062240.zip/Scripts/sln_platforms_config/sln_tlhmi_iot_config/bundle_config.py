#!/usr/bin/env python3

"""

Copyright 2022 NXP.

This software is owned or controlled by NXP and may only be used strictly in accordance with the
license terms that accompany it. By expressly accepting such terms or by downloading, installing,
activating and/or otherwise using the software, you are agreeing that you have read, and that you
agree to comply with and are bound by, such license terms. If you do not agree to be bound by the
applicable license terms, then you may not retain, install, activate or otherwise use the software.

File
++++

Brief
+++++
** Defines a dictionary that contains files to be added in the bundle when creating a bundle update bin
dictionary [(AppType, ImageBin, Cert Path, BootApplication)]
**

.. versionadded:: 0.0

"""

# Module types identifiers
##########################

from enum import IntEnum

#[MODULE_TYPE: (BIN_PATH, CERT_PATH)]
class BundleModuleType(IntEnum):
    INVALID         = -1
    BOOTLOADER      = 0 # Bootloader update is not supported for now
    APP_A           = 1
    APP_B           = 2
    RESOURCES_APP_A = 3
    RESOURCES_APP_B = 4

class BundleBinaryInfo():
      def __init__(self, module_type, path_bin, path_cert):
        self.module_type = module_type
        self.path_bin    = path_bin
        self.path_cert   = path_cert

# Place them in incremental address order
imageBundleList = (
    BundleBinaryInfo(BundleModuleType.APP_A, "../../../Image_Binaries/sln_tlhmi_iot_demo.bin", "prod.app.a"),
    BundleBinaryInfo(BundleModuleType.RESOURCES_APP_A, "../../../Image_Binaries/sln_tlhmi_iot_resources.bin", "prod.app.a"),
)

BUNDLE_CERT = "prod.app.a"
BUNDLE_NAME = "bundle.bin"