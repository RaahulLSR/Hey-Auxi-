#!/usr/bin/env python3

"""

Copyright 2022 NXP.

NXP Confidential. This software is owned or controlled by NXP and may only be used strictly in accordance
with the license terms that accompany it. By expressly accepting such terms or by downloading, installing,
activating and/or otherwise using the software, you are agreeing that you have read, and that you
agree to comply with and are bound by, such license terms. If you do not agree to be bound by the
applicable license terms, then you may not retain, install, activate or otherwise use the software.

File
++++
/Scripts/sln_tlhmi_iot_open_boot/open_prog_full.py

Brief
+++++
** Full suite script for SLN-TLHMI-IOT project. Onboarding, Programming. **

.. versionadded:: 0.0

"""

import argparse
import os
import sys
import subprocess
import Ivaldi.blhost as blhost
import Ivaldi.sdphost as sdphost
import Ivaldi.helpers as helpers
import Ivaldi.onboard.aws as ob
import time
import base64
from shutil import copyfile
from shutil import rmtree

dir_name             = ''
AWS_CRT_FILE_NAME    = 'aws_crt.pem'
AWS_PRVKEY_FILE_NAME = 'aws_prv.pem'
AWS_PUBKEY_FILE_NAME = 'aws_pub.pem'

def cert_cb(id, certPem):
    """
        Handles the generated PEM certificate.

        :param id: Certificate ID
        :type id: String
        :param certPem: PEM Encoded certificate
        :type certPem: String

        :returns: None
    """
    global dir_name
    pem_name = dir_name + '/' + AWS_CRT_FILE_NAME
    print(pem_name)
    with open(pem_name, 'w+') as c:
        c.write(certPem)
        c.close()

def pkey_cb(id, prvKey, pubKey):
    """
        Handles the generated PEM private key and public key.

        :param id: Certificate ID
        :type id: String
        :param prvKey: PEM Encoded Private Key
        :type prvKey: String
        :param pubKey: PEM Encoded Public Key
        :type pubKey: String

        :returns: None
    """
    global dir_name

    pub_name = dir_name + '/' + AWS_PUBKEY_FILE_NAME
    prv_name = dir_name + '/' + AWS_PRVKEY_FILE_NAME
    with open(pub_name, 'w+') as pub:
        pub.write(pubKey)
        pub.close()

    with open(prv_name, 'w+') as prv:
        prv.write(prvKey)
        prv.close()

def main():
    """
        Based on board_config, performs the following operations:
            - Erases:
                - FLASH_SIZE bytes of flash starting at address FLASH_START_ADDR
            - Programs:
                - BOOTLOADER_BIN                 @ BOOTLOADER_ADDR
                - APP_A_BIN                      @ APP_A_ADDR
                - fica_table.bin                 @ FICA_TABLE_ADDR

        :returns: None
    """
    global board_config
    global dir_name

    """ Parse the provided parameters """
    parser = argparse.ArgumentParser()
    parser.add_argument('-cf', '--config-folder', default="../sln_platforms_config/sln_tlhmi_iot_config/", type=str, help="Specify the folder that contains board_config.py file")
    parser.add_argument('-ivd', '--image-verification-disable', action='store_true', help="Disable Image Verification")
    parser.add_argument('-awsd', '--aws-disable', action='store_true', help="Disable AWS thing creation and thing certificates obtaining")
    parser.add_argument('-fbb', '--flash-bank-b', action='store_true', help="Flash second demo in bank B")
    parser.add_argument('-fbc', '--flash-bank-c', action='store_true', help="Flash third demo in bank C")
    args = parser.parse_args()

    """ Import board_config.py that contains the platform specs """
    try:
        print('Importing board_config.py from ' + args.config_folder + ' folder')
        sys.path.append(args.config_folder)
        import board_config
    except ImportError:
        print('ERROR: Could not import board_config.py file from ' + args.config_folder + ' folder')
        sys.exit(1)

    try:
        print('Importing littlefs_file_list.py from ' + args.config_folder + ' folder')
        sys.path.append(args.config_folder)
        import littlefs_file_list
    except ImportError:
        print('ERROR: Could not import littlefs_file_list.py file from ' + args.config_folder + ' folder')
        sys.exit(1)

    bl = blhost.BLHost()

    # Check communication with device
    print('Establishing connection...')
    if bl.check_connection(vid ='0x1fc9', pid='0x13d')['ret']:
        print('ERROR: Could not establish communication with device. Power cycle device.')
        sys.exit(1)
    else:
        print('SUCCESS: Communication established with device.')

    # Load flashloader onto device
    print('Loading flashloader...')
    if bl.load_image('../../Flashloader/ivt_flashloader_IMXRT1070.bin', vid ='0x1fc9', pid='0x13d')['ret']:
        print('ERROR: Could not write file!')
        sys.exit(1)
    else:
        print('SUCCESS: Flashloader loaded successfully.')

    # Poll device to make sure it is ready
    print('Waiting for device to be ready for blhost...')
    waitCount = 0
    while bl.get_property('0x01')['ret']:
        time.sleep(0.5)
        waitCount += 1
        if waitCount == 10:
            print('ERROR: Timeout waiting for device to be ready. Power cycle device and try again.')
            sys.exit(1)

    print('SUCCESS: Device is ready for blhost!')

    # Read out unique ID
    print('Reading device unique ID...')
    prop = bl.get_property('0x12')
    if prop['ret']:
        print('ERROR: Could not read device unique ID!')
        sys.exit(1)
    else:
        ser_num = helpers.encode_unique_id_to_hex(prop['response'])
        print('SUCCESS: Device serial number is %s' %(ser_num))

    # Set the ouput directory
    try:

        if not os.path.exists('../../Output/'):
            os.makedirs('../../Output/')
        dir_name = '../../Output/' + ser_num
        if os.path.isdir(dir_name):
            rmtree(dir_name)
        os.mkdir(dir_name)
    except OSError as e:
        print("Error: %s : %s" % (dir_path, e.strerror))

    # Write config option block to RAM
    print('Writing memory config option block...')
    if bl.fill_memory('0x2000', '0x4', board_config.OPTION_BLOCK_MASK)['ret']:
        print('ERROR: Could not fill memory!')
        sys.exit(1)
    else:
        print('SUCCESS: Config option block loaded into RAM.')

    # Configure FlexSPI
    print('Configuring FlexSPI...')
    if bl.configure_memory('0x9', '0x2000')['ret']:
        print('ERROR: Could not configure memory!')
        sys.exit(1)
    else:
        print('SUCCESS: FlexSPI configured.')

    # Erase flash
    print('Erasing flash can take up to 4 minutes...')
    if bl.flash_erase_all()['ret']:
        print('ERROR: Could not erase memory!')
        sys.exit(1)
    else:
        print('SUCCESS: Flash erased.')

    if not args.aws_disable:
        # Create a new MakeThing object
        new_thing = ob.MakeThing(clientType='iot', thingName=ser_num)

        # If an IoT thing with the same name already exists, delete it
        new_thing.clean()

        # Create new thing and credentials
        thing_data = new_thing.create(cert_callback=cert_cb, key_callback=pkey_cb)

        # Print for records
        print(thing_data)

        # Attach policy to the thing
        new_thing.attach('tlhmi_deployment')

        # Copy AWS certificates to an established location
        try:
            copyfile(dir_name + '/' + AWS_CRT_FILE_NAME, littlefs_file_list.PEM_CERTIFICATE_PATH)
            copyfile(dir_name + '/' + AWS_PRVKEY_FILE_NAME, littlefs_file_list.PEM_PRIVATE_KEY_PATH)
        except:
            print('ERROR: Unable to copy aws credentials!')
            sys.exit(1)

    # Write files to flash
    if board_config.BOOTSTRAP_ADDR != None:
        print('Programming bootstrap...')
        if not bl.write_memory(board_config.BOOTSTRAP_ADDR, '../../Image_Binaries/' + board_config.BOOTSTRAP_BIN)['status']:
            print('ERROR: Could not write file to memory!')
            sys.exit(1)
        else:
            print('SUCCESS: Bootstrap written to flash.')

    print('Programming bootloader at addr ' + board_config.BOOTLOADER_ADDR)
    if not bl.write_memory(board_config.BOOTLOADER_ADDR, '../../Image_Binaries/' + board_config.BOOTLOADER_BIN)['status']:
        print('ERROR: Could not write file to memory!')
        sys.exit(1)
    else:
        print('SUCCESS: Bootloader written to flash.')

    # Sign application and generate fica table
    if not args.image_verification_disable:
        try:
            copyfile('../../Image_Binaries/' + board_config.APP_A_BIN, '../ota_signing/sign/' + board_config.APP_A_BIN)
        except:
            print('ERROR: Unable to copy main demo!')
            sys.exit(1)

        try:
            copyfile('../../Image_Binaries/' + board_config.BOOTLOADER_BIN, '../ota_signing/sign/' + board_config.BOOTLOADER_BIN)
        except:
            print('ERROR: Unable to copy bootloader!')
            sys.exit(1)

        try:
            copyfile('../../Image_Binaries/' + board_config.RESOURCE_A_BIN, '../ota_signing/sign/' + board_config.RESOURCE_A_BIN)
        except:
            print('ERROR: Unable to copy resources from ../../Image_Binaries/' + board_config.RESOURCE_A_BIN)
            sys.exit(1)

        # NOTE: End user will need to update the device signing entity used below (by default prod.app.a used)
        # python sign_package.py -p PLATFORM_PREFIX -a prod.app.a
        cmd = ['python', 'sign_package.py', '-p', board_config.PLATFORM_PREFIX, '-m', board_config.MAIN_APP_NAME, '-bl', board_config.BOOTLOADER_NAME, '-r', board_config.MAIN_RESOURCE_NAME, '-a', 'prod.app.a', '-bc', board_config.ROOT_FOLDER]
        out = subprocess.run(cmd, cwd='../ota_signing/sign', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if out.returncode != 0:
            print(str(out.stdout.strip(), 'utf-8', 'ignore'))
            print(str(out.stderr.strip(), 'utf-8', 'ignore'))
            print('FICA generation failed')
            sys.exit(1)
        try:
            print(str(out.stdout.strip(), 'utf-8', 'ignore'))
            copyfile('../ota_signing/sign/fica_table.bin', '../../Image_Binaries/fica_table.bin')
        except:
            print('ERROR: Unable to copy fica table!')
            sys.exit(1)

        # Program FICA table
        print('Programming FICA table at addr ' + board_config.FICA_TABLE_ADDR)
        fica_path = '../../Image_Binaries/fica_table.bin'
        if not bl.write_memory(board_config.FICA_TABLE_ADDR, fica_path)['status']:
            print('ERROR: Could not program flash with FICA for this "thing"!')
            sys.exit(1)
        else:
            print('SUCCESS: Programmed flash with FICA for this "thing".')

    # Generate File-system
    filesListName = littlefs_file_list.getFilesListName(args.image_verification_disable, args.aws_disable)
    print("Generating File System with files from the list: " + filesListName)

    cmd = ['python', 'generate_image_littlefs.py', '-cf', args.config_folder, '-fln', filesListName]
    out = subprocess.run(cmd, cwd='../littlefs/', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if out.returncode != 0:
        print(str(out.stdout.strip(), 'utf-8', 'ignore'))
        print(str(out.stderr.strip(), 'utf-8', 'ignore'))
        print('File-system generation failed')
        sys.exit(1)
    try:
        print(str(out.stdout.strip(), 'utf-8', 'ignore'))
        copyfile('../littlefs/littlefs.bin', '../../Image_Binaries/'+ board_config.PLATFORM_PREFIX +'file_system.bin')
    except:
        print('ERROR: Unable to copy file-system table!')
        sys.exit(1)

    # Program File-system
    print('Programming file-system at addr ' + board_config.FILESYSTEM_ADDR)
    file_system_path = '../../Image_Binaries/' + board_config.PLATFORM_PREFIX + 'file_system.bin'
    if not bl.write_memory(board_config.FILESYSTEM_ADDR, file_system_path)['status']:
        print('ERROR: Could not program flash with file-system for this "thing"!')
        sys.exit(1)
    else:
        print('SUCCESS: Programmed flash with file-system for this "thing".')

    # Program Coffe_machine
    print('Programming Application Bank A at addr ' + board_config.APP_A_ADDR)
    if not bl.write_memory(board_config.APP_A_ADDR, '../../Image_Binaries/' + board_config.APP_A_BIN)['status']:
        print('ERROR: Could not write file to memory!')
        sys.exit(1)
    else:
        print('SUCCESS: Application Bank A written to flash.')

    print('Programming Resources Bank A at addr ' + board_config.APP_A_RESOURCES_ADDR)
    if not bl.write_memory(board_config.APP_A_RESOURCES_ADDR, '../../Image_Binaries/' + board_config.RESOURCE_A_BIN)['status']:
        print('ERROR: Could not write file to memory!')
        sys.exit(1)
    else:
        print('SUCCESS: Resources Bank A written to flash.')

    if args.flash_bank_b:
        # Program Elevator
        print('Programming Application Bank B at addr ' + board_config.APP_B_ADDR)
        if not bl.write_memory(board_config.APP_B_ADDR, '../../Image_Binaries/' + board_config.APP_B_BIN)['status']:
            print('ERROR: Could not write file to memory!')
            sys.exit(1)
        else:
            print('SUCCESS: Application Bank B written to flash.')

        print('Programming Resources Bank B at addr ' + board_config.APP_B_RESOURCES_ADDR)
        if not bl.write_memory(board_config.APP_B_RESOURCES_ADDR, '../../Image_Binaries/' + board_config.RESOURCE_B_BIN)['status']:
            print('ERROR: Could not write file to memory!')
            sys.exit(1)
        else:
            print('SUCCESS: Resources Bank B written to flash.')

    if args.flash_bank_c:
        # Program Home Panel
        print('Programming Application Bank C at addr ' + board_config.APP_C_ADDR)
        if not bl.write_memory(board_config.APP_C_ADDR, '../../Image_Binaries/' + board_config.APP_C_BIN)['status']:
            print('ERROR: Could not write file to memory!')
            sys.exit(1)
        else:
            print('SUCCESS: Application Bank C written to flash.')

        print('Programming Resources Bank C at addr ' + board_config.APP_C_RESOURCES_ADDR)
        if not bl.write_memory(board_config.APP_C_RESOURCES_ADDR, '../../Image_Binaries/' + board_config.RESOURCE_C_BIN)['status']:
            print('ERROR: Could not write file to memory!')
            sys.exit(1)
        else:
            print('SUCCESS: Resources Bank C written to flash.')

    # Get app entry point
    read_entry_resp = bl.read_memory(board_config.CODE_ENTRY_ADDR, '4')
    entry_pnt = 0
    if read_entry_resp['ret']:
        print('ERROR: Could ready memory!')
        sys.exit(1)
    else:
        entry_pnt = helpers.bytes_to_word(read_entry_resp['response'], 4)
        print('SUCCESS: Application entry point at %s' % (entry_pnt))

    # Get initial stack pointer
    read_sp_resp = bl.read_memory(board_config.STACK_POINTER_ADDR, '4')
    stack_pnt = 0
    if read_sp_resp['ret']:
        print('ERROR: Could ready memory!')
        sys.exit(1)
    else:
        stack_pnt = helpers.bytes_to_word(read_sp_resp['response'], 4)
        print('SUCCESS: Application stack pointer at %s' % (stack_pnt))

    # Execute application
    print('Attempting to execute application...')
    if bl.execute(entry_pnt, '0', stack_pnt)['ret']:
        print('ERROR: Could not execute application!')
        sys.exit(1)
    else:
        print('SUCCESS: Application running.')

if __name__ == '__main__':
    main()
