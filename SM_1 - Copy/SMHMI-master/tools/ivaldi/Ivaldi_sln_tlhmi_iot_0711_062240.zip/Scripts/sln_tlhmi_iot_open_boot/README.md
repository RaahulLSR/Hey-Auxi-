# SLN-TLHMI-IOT Open Boot Scripts

Scripts for using on an open device (HAB not enabled)

## Device executable binaries

The following executable binaries are loaded into flash by the Open Boot script:

- sln_tlhmi_iot_bootloader.bin
    - Programmed as plain text
- sln_tlhmi_iot_demo.bin
    - Programmed as plain text
- sln_tlhmi_iot_demo2.bin
    - Programmed as plain text
- sln_tlhmi_iot_resources.bin
    - Programmed as plain text
- sln_tlhmi_iot_resources2.bin
    - Programmed as plain text

sln_tlhmi_iot_demo.bin and sln_tlhmi_iot_resources.bin are flashed in bank A.
sln_tlhmi_iot_demo2.bin and sln_tlhmi_iot_resources2.bin are flashed in bank B if the parameter -fbb is used.

## Device Hardware Configuration

SLN-TLHMI-IOT platform supports 1 hardware configurations. Each of these configurations are described in the below files:
- Scripts/sln_platforms_config/sln_tlhmi_iot_config/board_config.py

Depending on the hardware, specify one of the available configurations to the programming script (example: python open_prog_full.py -cf ../sln_platforms_config/sln_tlhmi_iot_config/).

## Software Dependencies

- None

## Script options

```
open_prog_full.py has the following parameters:
    -cf, --config-folder    [CONFIG_FOLDER_PATH] Specify the folder that contains the board_config.py file for the current platform.
                            (default CONFIG_FOLDER_PATH = "../sln_platforms_config/sln_tlhmi_iot_config/")

    -ivd, --image-verification-disable  Specify to disable Image Verification feature (no certificates for the IV feature required)

    -awsd, --aws-disable                Specify to disable AWS thing creation and thing certificates obtaining

    -fbb,--flash-bank-b                 Flash second demo in bank B. If this parameter is not used, only bank A demo and resources will be flashed.
```

## Program Open SLN-TLHMI-IOT Application
There is a manufacturing tool for:
- Programming the binaries (these file names may need to change if different)

### 1. SLN-TLHMI-IOT

```
(env) user@host:~/sln_imx_rt_prog_and_test $ cd Scripts/sln_tlhmi_iot_open_boot
(env) user@host:~/sln_imx_rt_prog_and_test/Scripts/sln_tlhmi_iot_open_boot $ python open_prog_full.py -cf ../sln_platforms_config/sln_tlhmi_iot_config/
```
