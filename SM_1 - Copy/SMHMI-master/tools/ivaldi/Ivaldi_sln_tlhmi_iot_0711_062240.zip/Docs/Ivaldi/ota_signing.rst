.. mdinclude:: ../../Scripts/ota_signing/README.md
