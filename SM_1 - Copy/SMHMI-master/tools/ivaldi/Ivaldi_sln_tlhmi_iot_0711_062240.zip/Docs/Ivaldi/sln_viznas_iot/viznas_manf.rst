.. mdinclude:: ../../../Scripts/sln_viznas_iot_secure_boot/manf/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   viznas_enable_hab
