.. mdinclude:: ../../../Scripts/sln_viznas_iot_open_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   sln_viznas_iot_open_boot_src
