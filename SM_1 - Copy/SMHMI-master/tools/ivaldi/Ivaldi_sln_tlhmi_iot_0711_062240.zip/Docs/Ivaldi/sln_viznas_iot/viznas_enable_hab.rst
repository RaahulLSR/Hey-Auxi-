enable_hab
==========

.. automodule:: Scripts.sln_viznas_iot_secure_boot.manf.enable_hab
    :members: main
