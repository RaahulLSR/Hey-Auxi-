.. mdinclude:: ../../../Scripts/sln_viznas_iot_secure_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   viznas_manf
   viznas_oem
