read_fuse
=========

.. automodule:: Scripts.demos.read_fuse
    :members: main
