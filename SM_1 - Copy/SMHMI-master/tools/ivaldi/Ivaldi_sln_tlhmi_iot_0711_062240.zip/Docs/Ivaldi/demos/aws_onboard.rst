aws_onboard
===========

.. automodule:: Scripts.demos.aws_onboard
    :members: main

.. autofunction:: Scripts.demos.aws_onboard.cert_cb

.. autofunction:: Scripts.demos.aws_onboard.pkey_cb
