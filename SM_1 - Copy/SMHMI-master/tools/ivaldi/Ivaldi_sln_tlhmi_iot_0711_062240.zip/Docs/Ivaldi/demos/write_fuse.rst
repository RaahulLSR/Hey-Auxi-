write_fuse
==========

.. automodule:: Scripts.demos.write_fuse
    :members: main
