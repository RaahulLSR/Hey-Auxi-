.. mdinclude:: ../../../Scripts/demos/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   aws_onboard
   erase
   program_hello_world
   read_fuse
   read_serial
   write_fuse
