.. mdinclude:: ../../../Scripts/sln_local2_iot_secure_boot/oem/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   local2_setup_hab
   local2_secure_app
