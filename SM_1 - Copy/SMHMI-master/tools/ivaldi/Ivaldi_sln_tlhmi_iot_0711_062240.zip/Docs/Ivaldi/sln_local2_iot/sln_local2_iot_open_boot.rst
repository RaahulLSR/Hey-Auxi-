.. mdinclude:: ../../../Scripts/sln_local2_iot_open_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   local2_open_prog_full
