open_prog_full
==============

.. automodule:: Scripts.sln_local2_iot_open_boot.open_prog_full
    :members: main
