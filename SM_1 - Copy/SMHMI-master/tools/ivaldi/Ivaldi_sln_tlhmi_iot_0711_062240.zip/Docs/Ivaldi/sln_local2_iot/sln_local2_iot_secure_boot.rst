.. mdinclude:: ../../../Scripts/sln_local2_iot_secure_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   local2_manf
   local2_oem
