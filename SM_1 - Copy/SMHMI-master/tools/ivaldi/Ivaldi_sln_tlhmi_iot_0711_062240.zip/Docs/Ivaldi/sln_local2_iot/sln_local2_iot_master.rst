SLN_LOCAL2_IOT
==============

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   sln_local2_iot_open_boot
   sln_local2_iot_secure_boot