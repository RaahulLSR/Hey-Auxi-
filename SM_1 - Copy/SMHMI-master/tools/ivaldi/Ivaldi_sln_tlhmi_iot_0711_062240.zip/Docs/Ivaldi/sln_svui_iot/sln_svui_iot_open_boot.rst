.. mdinclude:: ../../../Scripts/sln_svui_iot_open_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   svui_open_prog_full
