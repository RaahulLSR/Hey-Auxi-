secure_app
==========

.. automodule:: Scripts.sln_svui_iot_secure_boot.oem.secure_app
    :members: main
