setup_hab
=========

.. automodule:: Scripts.sln_svui_iot_secure_boot.oem.setup_hab
    :members: main

.. autofunction:: Scripts.sln_svui_iot_secure_boot.oem.setup_hab.gen_enable_hab
