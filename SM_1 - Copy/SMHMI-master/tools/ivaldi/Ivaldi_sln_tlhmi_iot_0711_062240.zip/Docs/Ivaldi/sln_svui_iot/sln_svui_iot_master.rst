SLN_SVUI_IOT
==============

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   sln_svui_iot_open_boot
   sln_svui_iot_secure_boot