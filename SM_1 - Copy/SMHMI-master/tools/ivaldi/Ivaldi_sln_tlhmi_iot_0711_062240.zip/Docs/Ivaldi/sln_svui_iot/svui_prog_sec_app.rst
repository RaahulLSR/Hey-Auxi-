prog_sec_app
============

.. automodule:: Scripts.sln_svui_iot_secure_boot.manf.prog_sec_app
    :members: main
