.. mdinclude:: ../../../Scripts/sln_vizn_iot_secure_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   vizn_manf
   vizn_oem
