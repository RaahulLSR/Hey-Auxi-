.. mdinclude:: ../../../Scripts/sln_vizn_iot_secure_boot/manf/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   vizn_enable_hab
