sln_vizn_iot_open_boot
======================

.. automodule:: Scripts.sln_vizn_iot_open_boot.open_prog_full
    :members: main

