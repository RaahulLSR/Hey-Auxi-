.. mdinclude:: ../../../Scripts/sln_alexa_iot_secure_boot/oem/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   setup_hab
   secure_app
