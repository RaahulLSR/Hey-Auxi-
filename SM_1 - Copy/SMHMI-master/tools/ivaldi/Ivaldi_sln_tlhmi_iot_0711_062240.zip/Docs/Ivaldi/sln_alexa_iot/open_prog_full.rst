open_prog_full
==============

.. automodule:: Scripts.sln_alexa_iot_open_boot.open_prog_full
    :members: main

.. autofunction:: Scripts.sln_alexa_iot_open_boot.open_prog_full.cert_cb

.. autofunction:: Scripts.sln_alexa_iot_open_boot.open_prog_full.pkey_cb
