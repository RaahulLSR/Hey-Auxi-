SLN_ALEXA_IOT
=============

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   sln_alexa_iot_open_boot
   sln_alexa_iot_secure_boot
