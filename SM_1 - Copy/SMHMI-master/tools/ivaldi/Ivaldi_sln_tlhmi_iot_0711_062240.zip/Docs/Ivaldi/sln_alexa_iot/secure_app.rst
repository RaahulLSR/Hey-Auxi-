secure_app
==========

.. automodule:: Scripts.sln_alexa_iot_secure_boot.oem.secure_app
    :members: main
