enable_hab
==========

.. automodule:: Scripts.sln_alexa_iot_secure_boot.manf.enable_hab
    :members: main
