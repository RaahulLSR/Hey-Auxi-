.. mdinclude:: ../../../Scripts/sln_alexa_iot_open_boot/README.md

.. toctree::
   :maxdepth: 1
   :caption: Scripts:

   open_prog_full
