.. mdinclude:: ../../../Scripts/sln_platforms_config/sln_vizn3d_iot_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: board_config.py:

   vizn3d_board_config
