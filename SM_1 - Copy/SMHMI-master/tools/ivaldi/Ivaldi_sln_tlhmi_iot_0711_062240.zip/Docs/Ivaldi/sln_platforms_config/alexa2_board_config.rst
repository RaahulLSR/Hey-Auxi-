.. automodule:: Scripts.sln_platforms_config.sln_alexa2_iot_config.board_config
    :members:
