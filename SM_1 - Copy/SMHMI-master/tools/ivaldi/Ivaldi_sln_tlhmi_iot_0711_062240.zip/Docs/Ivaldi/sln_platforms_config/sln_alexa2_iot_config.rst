.. mdinclude:: ../../../Scripts/sln_platforms_config/sln_alexa2_iot_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: board_config.py:

   alexa2_board_config
