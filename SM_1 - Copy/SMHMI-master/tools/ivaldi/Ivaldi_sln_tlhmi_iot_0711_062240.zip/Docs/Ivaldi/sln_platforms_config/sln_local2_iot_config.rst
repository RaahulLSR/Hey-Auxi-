.. mdinclude:: ../../../Scripts/sln_platforms_config/sln_local2_iot_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: board_config.py:

   local2_board_config
