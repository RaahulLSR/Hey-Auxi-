.. automodule:: Scripts.sln_platforms_config.sln_vizn3d_iot_config.board_config
    :members:
