.. mdinclude:: ../../../Scripts/sln_platforms_config/README.md

.. toctree::
   :maxdepth: 1
   :caption: Configuration Files:

   sln_alexa_iot_config
   sln_alexa_iot_qspi_an_config
   sln_alexa2_iot_config
   sln_local2_iot_config
   sln_local2_rd_config
   sln_svui_iot_config
   sln_svui_rd_config
   sln_vizn3d_iot_config
